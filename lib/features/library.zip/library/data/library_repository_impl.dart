import 'package:readify_app/features/library/data/library_remote_data_source.dart';
import 'package:readify_app/features/library/domain/entities/user_book_model.dart';
import 'package:readify_app/features/library/domain/library_repository.dart';

class LibraryRepositoryImpl implements LibraryRepository {
  final LibraryRemoteDataSource _remoteDataSource;

  LibraryRepositoryImpl({required LibraryRemoteDataSource remoteDataSource})
    : _remoteDataSource = remoteDataSource;

  @override
  Future<List<UserBookModel>> getUserBooks() {
    return _remoteDataSource.fetchUserBooks();
  }

  @override
  Future<void> downloadUserBook({
    required int bookId,
    required String token,
  }) {
    return _remoteDataSource.downloadUserBook(
      bookId: bookId,
      token: token,
    );
  }

  @override
  Future<void> updateReadingProgress({
    required int bookId,
    required double progressPercentage,
  }) {
    return _remoteDataSource.updateReadingProgress(
      bookId: bookId,
      progressPercentage: progressPercentage,
    );
  }
}
