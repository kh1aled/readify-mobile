import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:readify_app/core/constants/app_constants.dart';
import 'package:readify_app/core/services/token_storage_service.dart';
import 'package:readify_app/features/library/domain/entities/user_book_model.dart';
import 'dart:html' as html;
class LibraryException implements Exception {
  final String message;
  const LibraryException(this.message);

  @override
  String toString() => message;
}

class LibraryRemoteDataSource {
  static const _baseUrl = AppConstants.apiBaseUrl;
  late http.Client _client;
  final TokenStorageService _tokenStorage;

  LibraryRemoteDataSource({
    http.Client? client,
    required TokenStorageService tokenStorage,
    Object? token,
  }) : _tokenStorage = tokenStorage {
    _client = client ?? http.Client();
  }

  Future<List<UserBookModel>> fetchUserBooks({String? token}) async {
    final response = await _client.get(
      Uri.parse('$_baseUrl/books/user'),
      headers: _jsonHeaders(token: token ?? _tokenStorage.getToken()),
    );

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final body = jsonDecode(response.body);

      // Accept both a plain list and a wrapped object { "userBooks": [...] }
      final List<dynamic> list = body is List
          ? body
          : (body['userBooks'] ?? body['data'] ?? body['items'] ?? [body]);

      return list
          .map((e) => UserBookModel.fromJson(e as Map<String, dynamic>))
          .toList();
    }

    throw LibraryException(
      'Failed to fetch user books (${response.statusCode})',
    );
  }

  Future<void> downloadUserBook({
    required int bookId,
    required String token,
  }) async {
    final url = Uri.parse('https://localhost:7287/api/books/download/$bookId');

    final response = await http.get(
      url,
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      final bytes = response.bodyBytes;

      final blob = html.Blob([bytes]);
      final blobUrl = html.Url.createObjectUrlFromBlob(blob);

      final anchor = html.AnchorElement(href: blobUrl)
        ..setAttribute("download", "book_$bookId.pdf")
        ..click();

      html.Url.revokeObjectUrl(blobUrl);
    } else {
      throw Exception('Download failed: ${response.statusCode}');
    }
  }

  /// PATCH /user/books/{bookId}/progress
  Future<void> updateReadingProgress({
    required int bookId,
    required double progressPercentage,
  }) async {
    final response = await _client.patch(
      Uri.parse('$_baseUrl/user/books/$bookId/progress'),
      headers: _jsonHeaders(),
      body: jsonEncode({'progressPercentage': progressPercentage}),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw LibraryException(
        'Failed to update progress for book $bookId (${response.statusCode})',
      );
    }
  }

  Map<String, String> _jsonHeaders({String? token}) => {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    if (token != null) 'Authorization': 'Bearer $token',
  };
}
