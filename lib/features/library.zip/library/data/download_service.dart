import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

class DownloadState {
  final bool isDownloading;
  final double progress; // 0 → 1
  final bool isComplete;
  final String? localPath;
  final String? error;

  const DownloadState({
    this.isDownloading = false,
    this.progress = 0.0,
    this.isComplete = false,
    this.localPath,
    this.error,
  });

  DownloadState copyWith({
    bool? isDownloading,
    double? progress,
    bool? isComplete,
    String? localPath,
    String? error,
  }) {
    return DownloadState(
      isDownloading: isDownloading ?? this.isDownloading,
      progress: progress ?? this.progress,
      isComplete: isComplete ?? this.isComplete,
      localPath: localPath ?? this.localPath,
      error: error,
    );
  }
}



class DownloadService extends ChangeNotifier {
  final Dio _dio = Dio();

  final Map<int, DownloadState> _states = {};

  DownloadState stateFor(int bookId) =>
      _states[bookId] ?? const DownloadState();

  bool isDownloaded(int bookId) =>
      _states[bookId]?.isComplete ?? false;

  Future<void> downloadBook({
    required int bookId,
    required String url,
    required String fileName,
    String? token,
  }) async {
    final current = _states[bookId];
    if (current?.isDownloading ?? false) return;

    _setState(bookId,
        const DownloadState(isDownloading: true, progress: 0));

    try {
      final dir = await getApplicationDocumentsDirectory();
      final filePath = '${dir.path}/$fileName';

      final file = File(filePath);

      if (await file.exists()) {
        _setState(
          bookId,
          DownloadState(
            isComplete: true,
            localPath: filePath,
          ),
        );
        return;
      }

      await _dio.download(
        url,
        filePath,
        options: Options(
          headers: {
            if (token != null) 'Authorization': 'Bearer $token',
          },
        ),
        onReceiveProgress: (received, total) {
          if (total > 0) {
            final progress = received / total;

            _setState(
              bookId,
              DownloadState(
                isDownloading: true,
                progress: progress,
              ),
            );
          }
        },
      );

      _setState(
        bookId,
        DownloadState(
          isComplete: true,
          progress: 1.0,
          localPath: filePath,
        ),
      );
    } on DioException catch (e) {
      _setState(
        bookId,
        DownloadState(
          error: e.message,
          isDownloading: false,
        ),
      );
    } catch (e) {
      _setState(
        bookId,
        DownloadState(
          error: e.toString(),
          isDownloading: false,
        ),
      );
    }
  }

  void _setState(int bookId, DownloadState state) {
    _states[bookId] = state;
    notifyListeners();
  }
}