import 'package:flutter/material.dart';
import 'package:readify_app/core/services/token_storage_service.dart';
import 'package:readify_app/features/library/data/download_service.dart';
import 'package:readify_app/features/library/domain/entities/user_book_model.dart';
import 'package:readify_app/features/library/presentation/widgets/book_list_item.dart';

class BookList extends StatelessWidget {
  const BookList({
    super.key,
    required this.books,
    required this.primaryColor,
    required this.downloadService,
    required this.tokenStorage,
    this.onBookTap,
  });

  final List<UserBookModel> books;
  final Color primaryColor;
  final DownloadService downloadService;
  final void Function(UserBookModel book)? onBookTap;
  final TokenStorageService tokenStorage;

  @override
  Widget build(BuildContext context) {
    if (books.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 48.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.library_books_outlined,
                  size: 48, color: Colors.black12),
              SizedBox(height: 12),
              Text(
                'No books here yet',
                style: TextStyle(color: Colors.black38, fontSize: 14),
              ),
            ],
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      itemCount: books.length,
      separatorBuilder: (_, __) =>
          Divider(color: Colors.grey.shade200, height: 1),
      itemBuilder: (context, index) {
        final book = books[index];
        return BookListItem(
          book: book,
          primaryColor: primaryColor,
          downloadService: downloadService,
          onTap: onBookTap != null ? () => onBookTap!(book) : null,
          tokenStorage: tokenStorage,
        );
      },
    );
  }
}
